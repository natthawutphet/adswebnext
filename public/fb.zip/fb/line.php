<?php
require 'config/db.php';

$stmt = $conn->query("SELECT * FROM weburl");
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row && isset($row['weburls'])) {
    $weburl = $row['weburls'];
    header("Location: $weburl");
    exit();
} else {
    // Redirect to a default page when no URL is retrieved from the database
    header("Location: default_page.php");
    exit();
}
?>
