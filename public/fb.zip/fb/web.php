<?php
require 'config/db.php';
$stmt = $conn->query("SELECT * FROM weburl");
$stmt->execute();
$urls = $stmt->fetchAll(); 
if(!$urls){ 
}else{  
 foreach($urls as $urlok)  { 
  $urlx = $urlok['weburls'];
 } }


$uipb=$_SERVER['REMOTE_ADDR'];




    $checkSql = $conn->prepare("SELECT COUNT(*) FROM ipb WHERE uipb = :uipb");
    $checkSql->bindParam(":uipb", $uipb);
    $checkSql->execute();
    $rowCount = $checkSql->fetchColumn();

    if ($rowCount == 0) {
    
    $sql = $conn->prepare("INSERT INTO ipb(uipb) VALUES(:uipb)");
    $sql->bindParam(":uipb", $uipb);
    $sql->execute();
    
    if ($sql){
        header("location:$urlx");
    }
    
} else {
    header("location:$urlx");
}

?>