<?php  require "../config/db.php";  


$stmt = $conn->query("SELECT * FROM pfb_b");
$stmt->execute();
$pixels = $stmt->fetchAll(); 



$stmt = $conn->query("SELECT * FROM imges");
$stmt->execute();
$imges = $stmt->fetchAll(); 

$stmt = $conn->query("SELECT * FROM modal");
$stmt->execute();
$modals = $stmt->fetchAll(); 



if (isset($_GET['pixel'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM pfb_b");
    $deletestmt->execute();

    if ($deletestmt) {
        echo "<script>alert('Data has been deleted successfully');</script>";
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
    
}
if (isset($_GET['imges'])) {
 
    $deletestmt = $conn->query("DELETE FROM imges");
    $deletestmt->execute();

    if ($deletestmt) {
        echo "<script>alert('Data has been deleted successfully');</script>";
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
    
}
if (isset($_GET['modal'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM modal");
    $deletestmt->execute();

    if ($deletestmt) {
        echo "<script>alert('Data has been deleted successfully');</script>";
        $_SESSION['success'] = "Data has been deleted succesfully";
        header("refresh:1; url=index.php");
    }
    
}





?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <style>
        #xxx {
 
 border: solid;
}
    </style>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

    
</haad>

<?php 
if(isset($del)) { ?>

<script>


swal({ title: "สวัดดีครับ", text: "สวัดดีครับ", type : "success", });





</script>
 <?php  } ?>

</head>
  <body>

  
  <div class="container-fluid">
  <div class="d-flex">
  <div class="p-2 flex-fill">
    
  <div id="xxx">
  <div class="text-center">  

  <?php 
  if (!$pixels) { ?>
    <?php  } else {

  foreach($pixels as $pixel)  { ?>
       
     
       <?php echo $pixel['pixel'];?> <form method="get">
        <input type="hidden"  name="id" value='<?php echo $pixel['id'];?>'>
        
        <button class="" type="submit"name="pixel">ลบ</button>
    </form> 
  

       <?php }}?>
      
       

             
       <form action="Add.php" method="post"><p>พิกเซล</p>
   
      <label for="inputPassword6" class="col-form-label">pixel</label>


<input type="text" name="pixel"  id="inputPassword6" class="form-control mb-3 " aria-describedby="passwordHelpInline" placeholder="ใส่พิกเซล">




      <button type="submit" name="submit_pixel">submit</button>
    
    
    
    
    </form>








  <!------------------------------------------>
  </div>
  </div>
  </div>

  <!---------------------------------------22222--->
  <div class="p-2 flex-fill">
  <div id="xxx">

<div class="text-center"> 

<form action="insert.php" method="post" enctype="multipart/form-data">
  <input type="file" name="img" required> <br><br>
  <button class="btn btn-success" type="submit" name="imges">submit</button></p>
  </form> 
  <?php 
  if (!$imges) { ?>
    <?php  } else {

  foreach($imges as $imgee)  { ?>
       
     
      <img src="img_up/<?php echo $imgee['img'];?>" width="100" alt=""><br>
  

       <?php } ?>
      <form method="get"><button class="" type="submit"name="imges">ลบ</button></form> 

       <?php } ?>




       </div>
  </div>
  </div>
    <!------------------------------------------>
  <div class="p-2 flex-fill">
    
  <div id="xxx">


<div class="text-center">  



  <?php 
  if (!$modals) { ?>

<form action="Add.php" method="post" enctype="multipart/form-data">
<input type="file" name="img" required> <br><br>

<br><br>
<button class="btn btn-success" type="submit" name="submitmd">submit</button></p><div class="text-center" >
</form> 




    <?php  } else {

  foreach($modals as $modal)  { ?>
       
       <img src="img_up/<?php echo $modal['img'];?>" width="100" alt=""><br>
      
  

       <?php } ?>
       <form method="get"><button class="" type="submit"name="modal">ลบ</button></form> 
    
       <?php } ?>
   


  </div>
  </div>
  </div>
</div>
</div>



















    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>