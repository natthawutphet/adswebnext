<?php session_start(); ?>
<?php


 







require "../config/db.php"; 


if(!isset($_SESSION['ok'])){
    $_SESSION['error'] = 'กรุณาใส่ข้อมูลถูกต้อง';
    header("location: login.php");
}
?>
<?php  
 require "db.php"; 
 
$stmt = $conn->query("SELECT * FROM pfb_b");
$stmt->execute();
$pixels = $stmt->fetchAll(); 


$stmt = $conn->query("SELECT * FROM weburl");
$stmt->execute();
$webs = $stmt->fetchAll(); 

$stmt = $conn->query("SELECT * FROM ipa");
$stmt->execute();
$ipas = $stmt->fetchAll(); 



$stmt = $conn->query("SELECT * FROM imges");
$stmt->execute();
$imges = $stmt->fetchAll(); 


$stmt = $conn->query("SELECT * FROM cimg");
$stmt->execute();
$bgs = $stmt->fetchAll(); 

$stmt = $conn->query("SELECT * FROM logos");
$stmt->execute();
$modals = $stmt->fetchAll(); 


$stmt = $conn->query("SELECT * FROM modal");
$stmt->execute();
$modal = $stmt->fetchAll(); 



if (isset($_GET['pixel'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM pfb_b WHERE id = $id");
    $deletestmt->execute();

    if ($deletestmt) {
        header("refresh:0.1; url=index.php");
    }
    
}
if (isset($_GET['cimg'])) {
    $deletestmt = $conn->query("DELETE FROM cimg");
    $deletestmt->execute();

    if ($deletestmt) {
        header("refresh:0.1; url=index.php");
    }
    
}

if (isset($_GET['imges'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM imges WHERE id = $id");
    $deletestmt->execute();
    if ($deletestmt) {
        if ($deletestmt) {
            header("refresh:0; url=index.php");
        }
    }
    
    
}
if (isset($_GET['submiturl'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM weburl");
    $deletestmt->execute();

    if ($deletestmt) {
        header("refresh:0.1; url=index.php");
    }
    
}
if (isset($_GET['logos'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM logos");
    $deletestmt->execute();

    if ($deletestmt) {
        header("refresh:0.1; url=index.php");
    }
    
}
if (isset($_GET['modal'])) {
    $id = $_GET['id'];
    $deletestmt = $conn->query("DELETE FROM modal");
    $deletestmt->execute();

    if ($deletestmt) {
        header("refresh:0; url=index.php");
    }
    
}





?>


<?php  
 require "db.php"; 

?>




<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="app.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        .none {
            display: none;
        }
    </style>
</head>

<body id="page-top">


<?php if (isset($_SESSION['success'])) { ?>
            <div class="alert alert-success">
                <?php 
                    echo $_SESSION['success'];
                    unset($_SESSION['success']); 
                    header("refresh:0.5; url=index.php");
                ?>
            </div>
        <?php } ?>
        <?php if (isset($_SESSION['error'])) { ?>
            <div class="alert alert-danger">
                <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']); 
                ?>
            </div>
        <?php } ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../" target="bank">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Home<sup></sup></div>
            </a>
           
            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="#">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
            <li class="nav-item active">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
 รายละเอียด
</button>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
         <?php 
     if(isset($_POST['open'])){
        $home = 1;
                    $sql = $conn->prepare("INSERT INTO modal(home) VALUES(:home)");
                    $sql->bindParam(":home", $home);
                    $sql->execute();
                    header("refresh:0; url=index.php");
     }



    if (!$modal){ ?>
        <form action="index.php" method="post">
        <button type="submit" name="open" class="btn btn-secondary">หน้าเทา</button>
       </form>
    <?php } else {
        foreach($modal as $mo)  { 
            $m = $mo['home'];
            if($m==1){ ?>
                <form action="index.php" method="get"> <button class="btn btn-warning" type="submit"name="modal">!หน้าขาว</button> </form> 
                <?php      } 
    }
    }



?>

     

       
          
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                           
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
              

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                           All members</div>
                                           
                                                <?php  
                                               $sql = "SELECT COUNT(*) as users FROM ipa";

                                               $query = $conn->prepare($sql);
                                               $query->execute();

                                               $fetch = $query->fetch();

                                                ?>
                                               <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                             $xo = $fetch['users'];
                                             echo $xo ?>
                                            </div>
                                               

                                        </div>
                                        <div class="col-auto">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>







                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                         
                                             สมัคร 
                                        
                                             </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php  
                                  
                                   $sql = "SELECT COUNT(*) as users FROM ipb";

                                   $query = $conn->prepare($sql);
                                   $query->execute();

                                   $x = $query->fetch();

                                    ?>
                                
                                <?php 
                                 $xox = $x['users'];
                                echo  $xox; ?>
                                 
                                   
                                                
                                                
                                   
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">ยอด
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                        <?php
                                                          $xx = $xox / $xo * 100; 
                                                   
                                 ?>
                                 <div id="percentage"></div>

 
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-info" role="progressbar"
                                                            style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           
                                        </div>
                                        <div class="col-auto">
                              </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-8 col-lg-7">
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">รายละเอียด ช่วงเวลา</h6>
                                    <div class="dropdown no-arrow"> 

                                 
                                  

        



                                    </div>
                                </div>
                            
                                <canvas id="myChart"></canvas>

                                   
                                <?php
// สมมติว่าคุณได้ดำเนินการ query และเตรียม $stmt ไว้แล้ว

$hours = array(); // อาร์เรย์สำหรับเก็บชั่วโมง
$records = array(); // อาร์เรย์สำหรับเก็บจำนวนระเบียน

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    array_push($hours, $row['Hour']);
    array_push($records, $row['NumberOfRecords']);
}

// แปลงอาร์เรย์เป็น JSON
$hours_json = json_encode($hours);
$records_json = json_encode($records);
?>
        
        <script>
const ctx = document.getElementById('myChart');

// รับข้อมูลจาก PHP และแปลงเป็น JSON
const hours = <?php echo $hours_json;?>;
const records = <?php echo $records_json; ?>;

new Chart(ctx, {
    type: 'bar',
    data: {
        labels: hours,
        datasets: [{
            label: 'แสดงช่วง เวลา ลูกค้าเข้าชม',
            borderWidth: 1,
            data: records
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>




                              
                            </div>
                        </div>


                 
            <!-- End of Main Content -->
    
  <div class="container-fluid">
  <div class="d-flex">
  <div class="p-2 flex-fill">
    
  <div id="xxx">
  <div class="text-center">  
<h3>พิกเซล</h3>
  <?php 
  if (!$pixels) { ?>
    <?php  } else {

  foreach($pixels as $pixel)  { ?>
       
     
          <?php echo $pixel['pixel'];?> <form method="get">
   
          <form action="index.php" method="get"> <input type="hidden" name="id" value="<?php echo $pixel['id'];?>">  
       <button class="" type="submit"name="pixel">ลบ</button> </form>
    

       <?php }?>
   
       <?php }?>
      
       

             
       <form action="Add.php" method="post">
   
      <label for="inputPassword6" class="col-form-label">พิกเซล</label>
<input type="text" name="pixel"  id="inputPassword6" class="form-control mb-3 " aria-describedby="passwordHelpInline" placeholder="ใส่พิกเซล">
      <button type="submit" name="submit_pixel">submit</button>
    </form>
<hr>

<hr>

<h3>Background</h3>


  <?php 
  if (!$bgs) { ?>
  <form action="insert.php" method="post" enctype="multipart/form-data">
  <input type="file" name="img" required> <br><br>
  <button class="btn btn-success" type="submit" name="submit">submit</button></p>
  </form> 
    <?php  } else {

  foreach($bgs as $bg)  { ?>
       
   
       <img src="BG/<?php echo $bg['img'];?>" width="100" alt=""><br>
        <input type="hidden"  name="id" value='<?php echo $pixel['id'];?>'>
        
       <br>
   
  

       <?php }?>
       <form action="index.php" method="get">   
       <button class="" type="submit"name="cimg">ลบ</button> </form> 
       <?php }?>



<hr>




  <!------------------------------------------>
  </div>
  </div>
  </div>

  <!---------------------------------------22222--->
  <div class="p-2 flex-fill">
  <div id="xxx">


<div class="">  
</div>


<div class="text-center"> 
    <h3>ใส่รูป โปรโมท</h3>

<form action="insert.php" method="post" enctype="multipart/form-data">
  

<input type="file" name="img" id='imge'class='input' required> <br><br>
<div class="none">
<input type="submit"  id="submitxxx" value="" name="imges"></div>



  </form> 

<style>
input.input {
border: 0.5px solid;
width: 180px;
height: 75px;

}

</style>






  <?php 
  if (!$imges) { ?>
    <?php  } else {

  foreach($imges as $imgee)  { ?>
       
     
      <img src="img_up/<?php echo $imgee['img'];?>" width="100" alt="">
  
      <form method="get">
      <input type="hidden" name="id" value="<?php echo $imgee['id'];?>">  
      <button class="" type="submit"name="imges">ลบ</button></form> 
       <?php } ?>
  

       <?php } ?>




       </div>
  </div>
  </div>
    <!------------------------------------------>
  <div class="p-2 flex-fill">
    
  <div id="xxx">


<div class="text-center"> 


    


 <br>
 <?php 
  if (!$webs) { 

   ?>

<form action="Add.php" method="post">
   
   <label for="inputPassword6" class="col-form-label">เว็บไซต์หรือลิงค์ไลน์</label>
<input type="text" name="weburls"  id="inputPassword6" class="form-control mb-3 " aria-describedby="passwordHelpInline" placeholder="ใส่ลิงค์เว็บไซต์หรือลิงค์ไลน์ https://domain.com">
   <button type="submit" name="submiturl">submit</button>
 </form>

<?php  } else {
foreach($webs as $web)  { ?>
 
<?php echo $web['weburls'];?>
<form method="get"><button class="" type="submit"name="submiturl">ลบ</button></form> 

<?php } ?>
<?php } ?>



<hr><hr>

้<h3>รูป  Pop Up (ไม่บังคับ)</h3>

  <?php 
  if (!$modals) { ?>

<form action="Add.php" method="post" enctype="multipart/form-data">
<input type="file" name="imglogo" id='imagein' required> <br><br>

<br><br>
<button class="btn btn-success" type="submit" id="submitx" name="submitlogo">submit</button></p><div class="text-center" >
</form> 

    <?php  } else {

  foreach($modals as $modal)  { ?>
       
       <img src="img_up/<?php echo $modal['imglg'];?>" width="100" alt=""><br>
      
       <?php } ?>
       <form method="get" action="index.php"><button class="" type="submit" name="logos">ลบ</button></form> 
    
       <?php } 
       
?>


  </div>
  </div>
  </div>
</div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
 

     

    </div>
  </div>
</div>



<main class="container d-flex">

<section class="p-2 flex-fill m-2" >

    <div class="text-center">

    <table class="table table-hover">
           
    <tr>
        <th>id</th>
        <th>IP</th>
        <th>referrer</th>
        <th>Time</th>
    </tr>

    <?php 
  if (!$ipas) { 
  } else {
    foreach($ipas as $ipa)  {  ?>
        <tr>
            <td><?php echo $ipa['id']; ?></td>
            <td><?php echo $ipa['uipa']; ?></td>
            <td><?php echo $ipa['referrer']; ?></td>
            <td><?php echo $ipa['time']; ?></td>
        </tr>
      <?php } } ?>



</table>

    </div>

</section>



<section class="p-3 flex-fill m-2" >

    <div class="text-center">

    <table class="table table-hover">
           
    <tr>
        <th>id</th>
        <th>IP</th>
        <th>referrer</th>
        <th>Time</th>
    </tr>

    <?php 
  if (!$ipas) { 
  } else {
    foreach($ipas as $ipa)  {  ?>
        <tr>
            <td><?php echo $ipa['id']; ?></td>
            <td><?php echo $ipa['uipa']; ?></td>
            <td><?php echo $ipa['referrer']; ?></td>
            <td><?php echo $ipa['time']; ?></td>
        </tr>
      <?php } } ?>



</table>

    </div>

</section>
</main>






















<script>
let imagein = document.getElementById('imge');

imagein.addEventListener('input', () => {
    autoClickButton();
})
// สร้างฟังก์ชันที่คลิกปุ่มโดยอัตโนมัติ
function autoClickButton() {

  var button = document.getElementById('submitxxx'); // เปลี่ยน 'myButton' เป็น ID ของปุ่มที่คุณต้องการคลิก

  if (button) {
    // ตรวจสอบว่าปุ่มมีอยู่จริง
    button.click(); // คลิกปุ่ม
  } else {
    console.log('ไม่พบปุ่ม'); // ถ้าไม่พบปุ่ม
  }
}

    
</script>

<script src="app.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>

